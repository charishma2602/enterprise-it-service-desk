# Enterprise IT Service Desk & Incident Management System

A beginner-friendly full-stack project using Java 21, Spring Boot, Spring Data JPA, MySQL, HTML, CSS and JavaScript.

## Features
- Create support tickets with employee details, category, priority and description
- View and search all tickets
- Filter tickets by status
- Assign a technician
- Change ticket status and priority
- Dashboard counts for total, open, in-progress and resolved tickets
- REST API with basic validation

## Requirements
- JDK 21
- Maven 3.9+ (or use IntelliJ's bundled Maven)
- MySQL 8.x (optional for first run; H2 is included for quick testing)

## Run quickly with H2
In `src/main/resources/application.properties`, set `spring.profiles.active=h2`.
Then run `mvn spring-boot:run` from this folder. Open http://localhost:8080.

## Run with MySQL
1. Create a database: `CREATE DATABASE it_service_desk;`
2. In `src/main/resources/application.properties`, set `spring.profiles.active=mysql`.
3. Update username/password in `application-mysql.properties` (or set `DB_USERNAME` and `DB_PASSWORD` environment variables).
4. Run `mvn spring-boot:run`.
5. Open http://localhost:8080.

## Demo API
- `GET /api/tickets`
- `GET /api/tickets/{id}`
- `POST /api/tickets`
- `PUT /api/tickets/{id}`
- `PATCH /api/tickets/{id}/status`
- `PATCH /api/tickets/{id}/assign`
- `GET /api/dashboard`

Example POST body:
```json
{
  "employeeName": "Asha Rao",
  "employeeEmail": "asha@example.com",
  "title": "Laptop not connecting to Wi-Fi",
  "category": "NETWORK",
  "priority": "HIGH",
  "description": "The laptop cannot connect to the office Wi-Fi."
}
```

## Important learning note
This is a learning/demo application. It does not implement production-grade authentication, authorization, audit logging, or data privacy controls. Do not deploy it with real employee data without adding those protections.
