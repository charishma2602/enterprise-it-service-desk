package com.charishma.servicedesk.repository;

import com.charishma.servicedesk.model.Ticket;
import com.charishma.servicedesk.model.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TicketRepository extends JpaRepository<Ticket, Long> {
    List<Ticket> findAllByOrderByCreatedAtDesc();
    List<Ticket> findByStatusOrderByCreatedAtDesc(TicketStatus status);
    long countByStatus(TicketStatus status);
}
