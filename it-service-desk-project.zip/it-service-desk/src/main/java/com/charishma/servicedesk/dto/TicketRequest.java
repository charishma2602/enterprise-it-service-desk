package com.charishma.servicedesk.dto;

import com.charishma.servicedesk.model.*;
import jakarta.validation.constraints.*;

public record TicketRequest(
    @NotBlank @Size(max = 100) String employeeName,
    @NotBlank @Email @Size(max = 150) String employeeEmail,
    @NotBlank @Size(max = 160) String title,
    @NotNull TicketCategory category,
    @NotNull TicketPriority priority,
    @NotBlank @Size(max = 2000) String description,
    TicketStatus status,
    @Size(max = 100) String assignedTo
) {}
