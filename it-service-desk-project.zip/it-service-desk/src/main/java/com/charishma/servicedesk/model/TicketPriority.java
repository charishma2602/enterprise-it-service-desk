package com.charishma.servicedesk.model;

public enum TicketPriority {
    LOW, MEDIUM, HIGH, URGENT
}
