package com.charishma.servicedesk.dto;

import com.charishma.servicedesk.model.TicketStatus;
import jakarta.validation.constraints.NotNull;

public record StatusRequest(@NotNull TicketStatus status) {}
