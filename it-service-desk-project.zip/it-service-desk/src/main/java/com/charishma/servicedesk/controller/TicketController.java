package com.charishma.servicedesk.controller;

import com.charishma.servicedesk.dto.*;
import com.charishma.servicedesk.model.*;
import com.charishma.servicedesk.repository.TicketRepository;
import com.charishma.servicedesk.service.TicketService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class TicketController {
    private final TicketService service;
    private final TicketRepository repository;

    public TicketController(TicketService service, TicketRepository repository) {
        this.service = service;
        this.repository = repository;
    }

    @GetMapping("/tickets")
    public List<Ticket> getTickets(@RequestParam(required = false) TicketStatus status) {
        return service.findAll(status);
    }

    @GetMapping("/tickets/{id}")
    public Ticket getTicket(@PathVariable Long id) { return service.findById(id); }

    @PostMapping("/tickets")
    public Ticket createTicket(@Valid @RequestBody TicketRequest request) {
        return service.create(request);
    }

    @PutMapping("/tickets/{id}")
    public Ticket updateTicket(@PathVariable Long id, @Valid @RequestBody TicketRequest request) {
        return service.update(id, request);
    }

    @PatchMapping("/tickets/{id}/status")
    public Ticket updateStatus(@PathVariable Long id, @Valid @RequestBody StatusRequest request) {
        return service.changeStatus(id, request.status());
    }

    @PatchMapping("/tickets/{id}/assign")
    public Ticket assignTicket(@PathVariable Long id, @Valid @RequestBody AssignmentRequest request) {
        return service.assign(id, request.assignedTo());
    }

    @GetMapping("/dashboard")
    public Map<String, Long> dashboard() {
        long total = repository.count();
        long open = repository.countByStatus(TicketStatus.OPEN);
        long progress = repository.countByStatus(TicketStatus.IN_PROGRESS);
        long resolved = repository.countByStatus(TicketStatus.RESOLVED);
        long closed = repository.countByStatus(TicketStatus.CLOSED);
        return Map.of("total", total, "open", open, "inProgress", progress,
                      "resolved", resolved, "closed", closed);
    }
}
