package com.charishma.servicedesk.model;

public enum TicketStatus {
    OPEN, IN_PROGRESS, RESOLVED, CLOSED
}
