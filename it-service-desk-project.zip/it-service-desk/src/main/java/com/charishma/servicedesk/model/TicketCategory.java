package com.charishma.servicedesk.model;

public enum TicketCategory {
    HARDWARE, SOFTWARE, NETWORK, ACCESS, OTHER
}
