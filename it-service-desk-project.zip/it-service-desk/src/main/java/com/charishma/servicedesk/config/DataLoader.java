package com.charishma.servicedesk.config;

import com.charishma.servicedesk.model.*;
import com.charishma.servicedesk.repository.TicketRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataLoader {
    @Bean
    CommandLineRunner loadDemoData(TicketRepository repository) {
        return args -> {
            if (repository.count() > 0) return;
            repository.save(make("Asha Rao", "asha@example.com", "Laptop cannot connect to Wi-Fi",
                TicketCategory.NETWORK, TicketPriority.HIGH,
                "The laptop cannot connect to the office Wi-Fi network.", TicketStatus.OPEN, null));
            repository.save(make("Rahul Kumar", "rahul@example.com", "Install approved software",
                TicketCategory.SOFTWARE, TicketPriority.MEDIUM,
                "Please install the approved PDF editing software.", TicketStatus.IN_PROGRESS, "Meera"));
            repository.save(make("Neha Sharma", "neha@example.com", "Email access restored",
                TicketCategory.ACCESS, TicketPriority.LOW,
                "Email access issue has been fixed and verified.", TicketStatus.RESOLVED, "Arjun"));
        };
    }

    private Ticket make(String name, String email, String title, TicketCategory category,
                        TicketPriority priority, String description, TicketStatus status, String assignee) {
        Ticket t = new Ticket();
        t.setEmployeeName(name); t.setEmployeeEmail(email); t.setTitle(title);
        t.setCategory(category); t.setPriority(priority); t.setDescription(description);
        t.setStatus(status); t.setAssignedTo(assignee);
        return t;
    }
}
