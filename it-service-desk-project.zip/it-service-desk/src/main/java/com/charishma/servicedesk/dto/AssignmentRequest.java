package com.charishma.servicedesk.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public record AssignmentRequest(@NotBlank @Size(max = 100) String assignedTo) {}
