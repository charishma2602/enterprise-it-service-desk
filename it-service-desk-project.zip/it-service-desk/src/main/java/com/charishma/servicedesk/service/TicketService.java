package com.charishma.servicedesk.service;

import com.charishma.servicedesk.dto.TicketRequest;
import com.charishma.servicedesk.model.*;
import com.charishma.servicedesk.repository.TicketRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@Service
public class TicketService {
    private final TicketRepository repository;

    public TicketService(TicketRepository repository) { this.repository = repository; }

    public List<Ticket> findAll(TicketStatus status) {
        return status == null ? repository.findAllByOrderByCreatedAtDesc()
                              : repository.findByStatusOrderByCreatedAtDesc(status);
    }

    public Ticket findById(Long id) {
        return repository.findById(id).orElseThrow(() ->
            new ResponseStatusException(HttpStatus.NOT_FOUND, "Ticket not found: " + id));
    }

    public Ticket create(TicketRequest request) {
        Ticket ticket = new Ticket();
        copyRequest(ticket, request);
        ticket.setStatus(TicketStatus.OPEN);
        return repository.save(ticket);
    }

    public Ticket update(Long id, TicketRequest request) {
        Ticket ticket = findById(id);
        copyRequest(ticket, request);
        if (request.status() != null) ticket.setStatus(request.status());
        return repository.save(ticket);
    }

    public Ticket changeStatus(Long id, TicketStatus status) {
        Ticket ticket = findById(id);
        ticket.setStatus(status);
        return repository.save(ticket);
    }

    public Ticket assign(Long id, String assignedTo) {
        Ticket ticket = findById(id);
        ticket.setAssignedTo(assignedTo.trim());
        return repository.save(ticket);
    }

    private void copyRequest(Ticket ticket, TicketRequest request) {
        ticket.setEmployeeName(request.employeeName().trim());
        ticket.setEmployeeEmail(request.employeeEmail().trim().toLowerCase());
        ticket.setTitle(request.title().trim());
        ticket.setCategory(request.category());
        ticket.setPriority(request.priority());
        ticket.setDescription(request.description().trim());
        ticket.setAssignedTo(request.assignedTo() == null || request.assignedTo().isBlank()
                ? null : request.assignedTo().trim());
    }
}
