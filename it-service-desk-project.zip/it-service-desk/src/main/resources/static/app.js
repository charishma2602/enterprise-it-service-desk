const API = "/api";
const rows = document.getElementById("ticketRows");
const message = document.getElementById("message");
let tickets = [];

async function api(path, options = {}) {
  const response = await fetch(API + path, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  if (!response.ok) {
    let detail = "Request failed";
    try { const body = await response.json(); detail = body.detail || body.message || body.error || detail; } catch {}
    throw new Error(detail);
  }
  if (response.status === 204) return null;
  return response.json();
}

async function loadDashboard() {
  const d = await api("/dashboard");
  document.getElementById("totalCount").textContent = d.total;
  document.getElementById("openCount").textContent = d.open;
  document.getElementById("progressCount").textContent = d.inProgress;
  document.getElementById("resolvedCount").textContent = d.resolved;
}

async function loadTickets() {
  try {
    const status = document.getElementById("statusFilter").value;
    tickets = await api("/tickets" + (status ? "?status=" + status : ""));
    renderTickets();
    await loadDashboard();
  } catch (e) { showMessage(e.message, true); }
}

function renderTickets() {
  const query = document.getElementById("searchInput").value.toLowerCase();
  const visible = tickets.filter(t =>
    [t.title, t.employeeName, t.employeeEmail, t.category, t.id].join(" ").toLowerCase().includes(query)
  );
  if (!visible.length) {
    rows.innerHTML = '<tr><td colspan="8" class="empty">No tickets found.</td></tr>';
    return;
  }
  rows.innerHTML = visible.map(t => `
    <tr>
      <td><div class="ticket-title">#${t.id} · ${escapeHtml(t.title)}</div><div class="subline">${escapeHtml(t.description.slice(0,65))}${t.description.length>65?"…":""}</div></td>
      <td>${escapeHtml(t.employeeName)}<div class="subline">${escapeHtml(t.employeeEmail)}</div></td>
      <td>${formatWords(t.category)}</td>
      <td><strong class="priority-${t.priority}">${formatWords(t.priority)}</strong></td>
      <td><span class="pill status-${t.status}">${formatWords(t.status)}</span></td>
      <td>${t.assignedTo ? escapeHtml(t.assignedTo) : "—"}</td>
      <td>${new Date(t.createdAt).toLocaleDateString()}</td>
      <td><button class="action" data-id="${t.id}">Manage</button></td>
    </tr>`).join("");
  rows.querySelectorAll("button[data-id]").forEach(btn => btn.addEventListener("click", () => openManage(Number(btn.dataset.id))));
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
function formatWords(value) { return value.toLowerCase().replaceAll("_", " ").replace(/\b\w/g, c => c.toUpperCase()); }
function showMessage(text, isError=false) {
  message.textContent = text;
  message.style.color = isError ? "#bd3b35" : "#34745b";
}

const ticketDialog = document.getElementById("ticketDialog");
document.getElementById("newTicketBtn").addEventListener("click", () => ticketDialog.showModal());
document.getElementById("closeDialog").addEventListener("click", () => ticketDialog.close());
document.getElementById("ticketForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = new FormData(event.target);
  const body = Object.fromEntries(form.entries());
  try {
    await api("/tickets", { method: "POST", body: JSON.stringify(body) });
    ticketDialog.close(); event.target.reset(); showMessage("Ticket created successfully."); await loadTickets();
  } catch (e) { showMessage(e.message, true); }
});

const manageDialog = document.getElementById("manageDialog");
document.getElementById("closeManage").addEventListener("click", () => manageDialog.close());
function openManage(id) {
  const t = tickets.find(item => item.id === id);
  if (!t) return;
  const form = document.getElementById("manageForm");
  form.elements.id.value = t.id;
  form.elements.assignedTo.value = t.assignedTo || "";
  form.elements.status.value = t.status;
  document.getElementById("manageTitle").textContent = `Manage ticket #${id}`;
  manageDialog.showModal();
}
document.getElementById("manageForm").addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.target, id = form.elements.id.value;
  try {
    const assignedTo = form.elements.assignedTo.value.trim();
    const status = form.elements.status.value;
    if (assignedTo) await api(`/tickets/${id}/assign`, { method: "PATCH", body: JSON.stringify({assignedTo}) });
    else {
      // Empty assignment is allowed by leaving the existing assignee unchanged.
    }
    await api(`/tickets/${id}/status`, { method: "PATCH", body: JSON.stringify({status}) });
    manageDialog.close(); showMessage("Ticket updated successfully."); await loadTickets();
  } catch (e) { showMessage(e.message, true); }
});

document.getElementById("searchInput").addEventListener("input", renderTickets);
document.getElementById("statusFilter").addEventListener("change", loadTickets);
loadTickets();
