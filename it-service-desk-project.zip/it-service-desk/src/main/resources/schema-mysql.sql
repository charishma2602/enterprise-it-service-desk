CREATE DATABASE IF NOT EXISTS it_service_desk;
USE it_service_desk;

-- Spring Data JPA creates/updates the tickets table from the Ticket entity.
-- This file is provided as a database setup reference.
